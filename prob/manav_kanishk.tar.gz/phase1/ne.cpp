#include<iostream>
using namespace std;
int main(){
    std::cout<<"k"<<"k";
}