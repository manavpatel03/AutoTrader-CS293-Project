#ifndef MARKET_H
#define MARKET_H
class market
{
public:
	market(int argc, char** argv);
	void start();
private:
};
#endif
