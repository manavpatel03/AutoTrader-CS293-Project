// This is your trader. Place your orders from here


#include <string>

int reader(int time)
{
    return 1;
}

int trader(std::string *message)
{
    return 1;
}
